import {
  Input,
  InputGroup,
  InputLeftAddon,
  Text,
  Divider,
  Stack, 
  Button,
  HStack,
  Link,
  } from '@chakra-ui/react'
import { FaUserAlt, FaLock, FaPhone, FaWeixin, FaQq } from "react-icons/fa";

export default function SignUp () {
  return (
    <form>
      <Stack spacing={8}>
        <Stack>
          <InputGroup>
            <InputLeftAddon children={<FaUserAlt/>}/>
            <Input placeholder="你的昵称" />
          </InputGroup>
          <InputGroup>
            <InputLeftAddon children={<FaPhone/>} />
            <Input placeholder="手机号"/>
          </InputGroup>
          <InputGroup>
            <InputLeftAddon children={<FaLock/>} />
            <Input type="password" placeholder="设置密码"/>
          </InputGroup>
        </Stack>
        <Button color="white" bgColor="#42c02e" _hover={{bgColor: '#3db922'}} borderRadius="30px" >
          注册
        </Button>
        <Text fontSize="12px" color="gray.500" textAlign="center">
          点击 “注册” 即表示您同意并愿意遵守简书
          <Link color="#3194d0" href="#">用户协议</Link>
          和
          <Link color="#3194d0" href="#">隐私政策 </Link>
          。
        </Text>
        <HStack justifyContent="space-between">
          <Divider w={1/4} />
          <Text color="gray.500" fontSize="12px">社交帐号直接注册</Text>
          <Divider w={1/4} />
        </HStack>
        <HStack fontSize="2xl" justifyContent="center" spacing="5">
          <FaWeixin color="#00bb29"/>
          <FaQq color="#498ad5"/>
        </HStack>
      </Stack>
    </form>
  )
}