import { Box, Button, Image, Text } from "@chakra-ui/react";
import { Link, Route } from 'react-router-dom';
import SignIn from './SignIn'
import SignUp from './SignUp'

export default function App () {
  return (
    <Box bg="gray.100" h="100vh">
      <Image src="https://cdn2.jianshu.io/assets/web/logo-58fd04f6f0de908401aa561cda6a0688.png" pos="absolute" top={10} left={10} />
      <Box w="820px" d="flex" mx="auto" mt={2} bgImage="url(//cdn2.jianshu.io/assets/web/sign_in_bg-bbc515a9c2e7734807ea281b9b2ab380.png)" bgSize="40%" bgPos="45px 0" pos="relative" bgRepeat="no-repeat">
        <Box w={1/2} p={2} h="500px" alignItems="flex-end" d="flex" justifyContent="center">
          <Button bg="tomato" color="white" borderRadius="30px" overflow="hidden">下载简书APP</Button>
        </Box>
        <Box w={1/2} p={10} bg="white" boxShadow="lg" borderRadius="lg" overflow="hidden">
          <Box d="flex" justifyContent="space-around">
            <Link to="/sign_in"><Text color="#ea6f5a" fontSize="2xl" fontWeight="lg">登录</Text></Link>
            <Link to="/sign_up"><Text color="gray.900" fontSize="2xl" fontWeight="lg">注册</Text></Link>
          </Box>
          <Box p={5}>
            <Route path="/sign_in" component={SignIn}/>
            <Route path="/sign_up" component={SignUp}/>
          </Box>
        </Box>
      </Box>
    </Box>
  )
}