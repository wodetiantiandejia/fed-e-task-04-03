import LaGouButton from './Button'

export default {
  LaGouButton
}